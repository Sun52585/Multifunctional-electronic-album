#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/types.h>          
#include <sys/socket.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>


int terminate = 0;



//./tcp_server  ipstring  port
int main(int argc, char *argv[])
{
	int sock;

	/*
	step 1:����һ���׽���(SOCK_STREAM)
	*/
	sock = socket(AF_INET, SOCK_STREAM, 0);
	if (sock == -1)
	{
		perror("socket error:");
		return -1;
	}


	/*
	step 2: ��һ��"������֪"�Ķ˿�
	*/
	struct sockaddr_in sAddr;
	memset(&sAddr, 0, sizeof(sAddr));
	sAddr.sin_family = AF_INET;
			//atoi��һ�������ַ������һ������
			//atoi("1234") =>  1234
	sAddr.sin_port = htons ( atoi(argv[2]) );
	sAddr.sin_addr.s_addr = inet_addr(argv[1]); 
	//sAddr.sin_addr.s_addr = htonl(  INADDR_ANY );
	
	int r = connect(sock, (struct sockaddr*) &sAddr, sizeof(sAddr));
	if (r == -1)
	{
		perror("connect error:");
		return -1;
	}

	char buf[256];
	r = read(sock, buf, 255);
	if (r == -1)
	{
		buf[r] = '\0';
		printf("%s\n", buf);
		
	}
	char *str = "byebye";
	write(sock, str, strlen(str));

	close(sock);

}
