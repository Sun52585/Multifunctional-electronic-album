
#include <sys/types.h>
#include <dirent.h>
#include <stdio.h>
#include <errno.h>
//#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/types.h>          
#include <sys/socket.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/select.h>


#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>


#include "protocol.h"

#define FTP_ROOT_DIR "/home/csgec/tftp"



int terminate = 0; //�����˳���־


int write_check(int fd, char *buf, int len)
{
	int total_writes = 0;//�ܹ�д�˶��ٸ��ֽ�
	int r;

	while (total_writes < len)
	{
		r = write(fd, buf + total_writes,  len - total_writes);
		if (r > 0)
		{
			total_writes += r;
		} else if (r < 0)
		{
			perror("write error:");
			return -1;
		}
	}


	return total_writes;
}



int read_check(int fd, char *buf, int len)
{
	int total_read = 0; //�ܹ����˶����ֽ�
	int r;

	while (total_read < len)
	{
		r = read(fd, buf + total_read, len - total_read);
		if (r > 0)
		{
			total_read += r;
		} else if(r <= 0)
		{
			perror("read error:");
			return -1;
		}
		
	}

	return total_read;
}

void ftp_cmd_ls(int connfd)
{
	printf("%s L_%d\n", __FUNCTION__, __LINE__);
	//char *filenames = malloc(4096);	
	unsigned char filenames[4096];
	DIR *dir = NULL;
	dir = opendir(FTP_ROOT_DIR);
	if (dir == NULL)
	{
		perror("opendir error:");
		return ;
	}

	int r = 0;
	struct dirent *dirp = NULL;
	while (dirp = readdir(dir))
	{
		r += sprintf(filenames + r, "%s ", dirp->d_name);	
		
	}

	closedir(dir);


	printf("%s L_%d: %s\n", __FUNCTION__, __LINE__, filenames);

	int pkg_len = 4 + 4  + 4 + 1 + r ;
	int cmd_no = FTP_CMD_LS;
	int resp_len = 1 + r;
	int i = 0;
	unsigned char *resp = malloc(2 +  pkg_len);
	resp[i++] = 0xc0; //��ͷ

			//�����ĸ��ֽ�Ϊpkg_len, ΪС��ģʽ
	resp[i++] = pkg_len & 0xff;
	resp[i++] = (pkg_len >> 8) & 0xff;
	resp[i++] = (pkg_len >> 16) & 0xff;
	resp[i++] = (pkg_len >> 24) & 0xff;


		//�����ĸ��ֽ�Ϊ����ţ�ΪС��ģʽ
	resp[i++] = cmd_no & 0xff;
	resp[i++] = (cmd_no >> 8) & 0xff;
	resp[i++] = (cmd_no >> 16) & 0xff;
	resp[i++] = (cmd_no >> 24) & 0xff;


		//�����ĸ��ֽ�Ϊ�ظ����ȣ�ΪС��ģʽ
	resp[i++] = resp_len & 0xff;
	resp[i++] = (resp_len >> 8) & 0xff;
	resp[i++] = (resp_len >> 16) & 0xff;
	resp[i++] = (resp_len >> 24) & 0xff;

		//����һ���ֽ�Ϊ�����0��ʾ�ɹ�������ֵ��ʾʧ��
	resp[i++] = 0;

	int j;
	for ( j = 0; j < r; j++)
	{
		resp[i++] = filenames[j];
	}
	resp[i++] = 0xc0; //��β

	j = write_check(connfd, resp, i);
	if (j != i)
	{
		printf("%s L_%d\n", __FUNCTION__, __LINE__);
	}
	printf("%s L_%d\n", __FUNCTION__, __LINE__);

	free(resp);
}

void ftp_cmd_get( int connfd, char *filename)
{
	printf("get %s\n", filename);

	int fd;
	char path[512];
	sprintf(path, "%s/%s", FTP_ROOT_DIR, filename);
	struct stat st;
	int r = stat(path, &st);
	if (r == 0)
	{
		fd = open(path, O_RDONLY);
		if (fd == -1)
		{
			r = errno;
		}
	}
	

	int pkg_len = 4 + 4  + 4 + 1 +4;
	int cmd_no = FTP_CMD_GET;
	int resp_len = 1 + 4;
	int i = 0;
	unsigned char *resp = malloc(2 +  pkg_len);
	resp[i++] = 0xc0; //��ͷ

			//�����ĸ��ֽ�Ϊpkg_len, ΪС��ģʽ
	resp[i++] = pkg_len & 0xff;
	resp[i++] = (pkg_len >> 8) & 0xff;
	resp[i++] = (pkg_len >> 16) & 0xff;
	resp[i++] = (pkg_len >> 24) & 0xff;


		//�����ĸ��ֽ�Ϊ����ţ�ΪС��ģʽ
	resp[i++] = cmd_no & 0xff;
	resp[i++] = (cmd_no >> 8) & 0xff;
	resp[i++] = (cmd_no >> 16) & 0xff;
	resp[i++] = (cmd_no >> 24) & 0xff;


		//�����ĸ��ֽ�Ϊ�ظ����ȣ�ΪС��ģʽ
	resp[i++] = resp_len & 0xff;
	resp[i++] = (resp_len >> 8) & 0xff;
	resp[i++] = (resp_len >> 16) & 0xff;
	resp[i++] = (resp_len >> 24) & 0xff;

		//����һ���ֽ�Ϊ�����0��ʾ�ɹ�������ֵ��ʾʧ��
	resp[i++] = r;

	int resp_content ; //filesize or errno
	if (r) // ʧ����
	{
		resp_content = r ;
	}
	else
	{
		resp_content = st.st_size;
	}
	
	resp[i++] = resp_content & 0xff;
	resp[i++] = (resp_content >> 8) & 0xff;
	resp[i++] = (resp_content >> 16) & 0xff;
	resp[i++] = (resp_content >> 24) & 0xff;


	resp[i++] = 0xc0; //��β

	int j = write_check(connfd, resp, i);
	if (j != i)
	{
		printf("%s L_%d\n", __FUNCTION__, __LINE__);
	}
	printf("%s L_%d\n", __FUNCTION__, __LINE__);

	free(resp);


	if (r == 0)
	{
		int total_send = 0;
		char buf[1024];
		while (total_send < st.st_size)
		{
			r = read(fd, buf, (st.st_size - total_send) > 1024 ? 1024 : (st.st_size - total_send) );
			if (r > 0)
			{
				write_check(connfd, buf, r);
				total_send += r;
			}
		}
	}

	close(fd);
	
}


void ftp_handle_cmd(int connfd, unsigned char *cmd, int len)
{
	int pkg_len;
	int cmd_no;
	int i = 0;


	//debug
	int j;
	for (j = 0; j < len; j++)
	{
		printf("%02x ", cmd[j] & 0xff);
	}
	printf("\n");

	

	if (len < 8)
	{
		return ;
	}

	pkg_len =( cmd[i++] & 0xff)
			| ((cmd[i++] & 0xff) << 8) 
			|((cmd[i++] & 0xff) << 16)
			|((cmd[i++] & 0xff) << 24) ;
	printf("pkg_len = %d len = %d\n", pkg_len, len);
	if (pkg_len != len)
	{
		return ;
	}

	cmd_no =( cmd[i++] & 0xff)
			| ((cmd[i++] & 0xff) << 8) 
			|((cmd[i++] & 0xff) << 16)
			|((cmd[i++] & 0xff) << 24) ;
	

	if (cmd_no >= FTP_CMD_NUM)
	{
		return ;
	}

	printf("cmd_no = %d\n", cmd_no);

	switch(cmd_no)
	{
		case FTP_CMD_LS:
			ftp_cmd_ls(connfd);
			break;
		case FTP_CMD_GET:
			ftp_cmd_get(connfd, cmd + i + 4 );
		default:
			break;
	}

}

void handle_connection(int connfd)
{
	char *cmd = malloc(4096);
	int r ;
	int i = 0;

	printf("%s L_%d\n", __FUNCTION__, __LINE__);

	while (!terminate)
	{
		printf("%s L_%d\n", __FUNCTION__, __LINE__);
		
		/*step 1 : ��������*/
		i = 0; //zhoulong

		unsigned char ch;
		do 
		{
			read(connfd, &ch, 1);
			
		}while(ch != 0xc0);

		printf("%s L_%d\n", __FUNCTION__, __LINE__);
		do
		{
			read(connfd, &ch, 1);
			if (ch != 0xc0)
			{
				cmd[i++] = ch;
			}
			
		}while (ch != 0xc0);	

	
		printf("%s L_%d\n", __FUNCTION__, __LINE__);
		/*step 2: ��������*/
		ftp_handle_cmd(connfd, cmd, i);
	
	}

	free(cmd);
	close(connfd);
}

void sig_handler(int signo)
{
	switch(signo)
	{
		case SIGINT:
			terminate = 1;
			break;
		default:
			break;
	}
}

int main(int argc, char *argv[])
{

	signal(SIGINT, sig_handler);
	/*
		socket -> bind -> listen
	*/
	int sock;

	/*
	step 1:����һ���׽���(SOCK_STREAM)
	*/
	sock = socket(AF_INET, SOCK_STREAM, 0);
	if (sock == -1)
	{
		perror("socket error:");
		return -1;
	}


	/*
	step 2: ��һ��"������֪"�Ķ˿�
	*/
	struct sockaddr_in sAddr;
	memset(&sAddr, 0, sizeof(sAddr));
	sAddr.sin_family = AF_INET;
			//atoi��һ�������ַ������һ������
			//atoi("1234") =>  1234
	sAddr.sin_port = htons ( atoi(argv[2]) );
	sAddr.sin_addr.s_addr = inet_addr(argv[1]); 
	//sAddr.sin_addr.s_addr = htonl(  INADDR_ANY );
	
	int r = bind(sock, (struct sockaddr*) &sAddr, sizeof(sAddr));
	if (r == -1)
	{
		perror("bind error:");
		return -1;
	}

	/*
	step 3: ���ü�����
	*/
	r = listen(sock, 10);
	if (r == -1)
	{
		perror("listen error:");
		return -1;
	}


	while (!terminate)
	{
		int max_fd =0;
		fd_set rfds; //
		FD_ZERO(&rfds);


		/* ����������룬�ж���ļ�ʱ���Ͷ��ִ��*/
		FD_SET(sock, &rfds); //����һ����������������ȥ
		if (sock >= max_fd)
		{
			max_fd = sock + 1;
		}
		

		struct timeval tv;
		tv.tv_sec = 3;
		tv.tv_usec = 0;

		int r = select(max_fd, &rfds, NULL, NULL, &tv);
		if (r <= 0)
		{
			continue;
		}

		if (FD_ISSET(sock, &rfds)) //sock �Ƿ��ڼ���rfds�У
		{						//��select ���غ���rfds�����е��ļ���������ʾ�ɶ���
		
			int connfd;
			struct sockaddr_in  clientAddr;
			socklen_t addrlen = sizeof(clientAddr);
			
			connfd = accept(sock, (struct sockaddr *)&clientAddr, &addrlen );
			if (connfd > 0)
			{
				printf("connection from %s[%d]\n", 
					inet_ntoa(clientAddr.sin_addr), ntohs(clientAddr.sin_port));

				pid_t pid = fork();
				if (pid > 0)
				{
					close(connfd);
				} else if (pid == 0)
				{
					handle_connection(connfd);
					exit(0);
				}


			}

		}

		//if (FD_ISSET(fd, &rfds))
		//{}
	}
}
