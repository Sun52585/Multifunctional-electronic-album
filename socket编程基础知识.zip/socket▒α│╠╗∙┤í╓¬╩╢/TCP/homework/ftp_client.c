#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/types.h>          
#include <sys/socket.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>


#include "protocol.h"

int ternimate = 0;

int write_check(int fd, char *buf, int len)
{
	int total_writes = 0;//�ܹ�д�˶��ٸ��ֽ�
	int r;

	int j;
	for (j = 0; j < len; j++)
	{
		printf("%02x ", buf[j] & 0xff);
	}
	printf("\n");



	while (total_writes < len)
	{
		r = write(fd, buf + total_writes,  len - total_writes);
		if (r > 0)
		{
			total_writes += r;
		} else if (r < 0)
		{
			perror("write error:");
			return -1;
		}
	}


	return total_writes;
}

void cmd_ls_resp(unsigned char resp[], int len)
{
	unsigned int  pkg_len;
	int cmd_no;
	int resp_len;
	int i = 0, j;
	unsigned char buf[4];

	printf("%02x %02x %02x %02x \n", 
			resp[0] & 0xff, 
			resp[1] & 0xff,
			resp[2] & 0xff,
			resp[3] & 0xff);

	
	//buf[]
	for (j = 0; j < 4; j++)
	{
		buf[j] = resp[i++];
	}
	
	pkg_len =( buf[0] & 0x000000ff)
			|((buf[1] << 8)  & 0x0000ff00) 
			|((buf[2] << 16) & 0x00ff0000)
			|((buf[3] << 24) & 0xff000000 ) ;
	
	printf("pkg_len = %d len = %d\n", pkg_len, len);
	
	if (pkg_len != len)
	{
		return ;
	}

	for (j = 0; j < 4; j++)
	{
		buf[j] = resp[i++];
	}
	
	cmd_no =( buf[0] & 0xff)
			| ((buf[1] & 0xff) << 8) 
			|((buf[2] & 0xff) << 16)
			|((buf[3] & 0xff) << 24) ;

	printf("cmd_no = %d,FTP_CMD_LS = %d\n ", cmd_no, FTP_CMD_LS);
	if (cmd_no != FTP_CMD_LS)
	{
		return ;
	}

	for (j = 0; j < 4; j++)
	{
		buf[j] = resp[i++];
	}
	resp_len =( buf[0] & 0xff)
			| ((buf[1] & 0xff) << 8) 
			|((buf[2] & 0xff) << 16)
			|((buf[3] & 0xff) << 24) ;


	int result = resp[i++];
	printf("%s L_%d result = %d \n", __FUNCTION__, __LINE__, result);
	if (result == 0)
	{
		printf("%s\n", resp + i);
	}
	
}

/*
	return 0��ʾOK
*/
int  cmd_get_resp(unsigned char resp[], int len  , int *filesize)
{
	unsigned int  pkg_len;
	int cmd_no;
	int resp_len;
	int i = 0, j;
	unsigned char buf[4];

	//printf("%02x %02x %02x %02x \n", 
	//		resp[0] & 0xff, 
	//		resp[1] & 0xff,
	//		resp[2] & 0xff,
	//		resp[3] & 0xff);

	
	//buf[]
	for (j = 0; j < 4; j++)
	{
		buf[j] = resp[i++];
	}
	
	pkg_len =( buf[0] & 0x000000ff)
			|((buf[1] << 8)  & 0x0000ff00) 
			|((buf[2] << 16) & 0x00ff0000)
			|((buf[3] << 24) & 0xff000000 ) ;
	
	printf("pkg_len = %d len = %d\n", pkg_len, len);
	
	if (pkg_len != len)
	{
		return -1;
	}

	for (j = 0; j < 4; j++)
	{
		buf[j] = resp[i++];
	}
	
	cmd_no =( buf[0] & 0xff)
			| ((buf[1] & 0xff) << 8) 
			|((buf[2] & 0xff) << 16)
			|((buf[3] & 0xff) << 24) ;

	printf("cmd_no = %d,FTP_CMD_GET = %d\n ", cmd_no, FTP_CMD_GET);
	if (cmd_no != FTP_CMD_GET)
	{
		return -1;
	}

	for (j = 0; j < 4; j++)
	{
		buf[j] = resp[i++];
	}
	resp_len =( buf[0] & 0xff)
			| ((buf[1] & 0xff) << 8) 
			|((buf[2] & 0xff) << 16)
			|((buf[3] & 0xff) << 24) ;


	int result = resp[i++];
	printf("%s L_%d result = %d \n", __FUNCTION__, __LINE__, result);


	for (j = 0; j < 4; j++)
	{
		buf[j] = resp[i++];
	}

	*filesize =( buf[0] & 0xff)
			| ((buf[1] & 0xff) << 8) 
			|((buf[2] & 0xff) << 16)
			|((buf[3] & 0xff) << 24) ;

	return result;
	
}


void cmd_ls(int connfd, char *cmd)
{
	int cmd_no = FTP_CMD_LS;
	int pkg_len = 4 + 4;

	printf("%s L_%d\n", __FUNCTION__, __LINE__);

	unsigned char send_cmd[10];
	int i = 0;

	send_cmd[i++] = 0xc0; //��ͷ

		//�����ĸ��ֽ�Ϊpkg_len, ΪС��ģʽ
	send_cmd[i++] = pkg_len & 0xff;
	send_cmd[i++] = (pkg_len >> 8) & 0xff;
	send_cmd[i++] = (pkg_len >> 16) & 0xff;
	send_cmd[i++] = (pkg_len >> 24) & 0xff;


		//�����ĸ��ֽ�Ϊ����ţ�ΪС��ģʽ
	send_cmd[i++] = cmd_no & 0xff;
	send_cmd[i++] = (cmd_no >> 8) & 0xff;
	send_cmd[i++] = (cmd_no >> 16) & 0xff;
	send_cmd[i++] = (cmd_no >> 24) & 0xff;

	send_cmd[i++] = 0xc0;//��β

	int r = write_check(connfd, send_cmd, i);
	if (r != i)
	{
		printf("%s L_%d\n", __FUNCTION__, __LINE__);
	}

	printf("%s L_%d\n", __FUNCTION__, __LINE__);




	/**/
	unsigned char *resp = malloc(8192);
	unsigned char ch;
	do 
	{
		read(connfd, &ch, 1);
		
	}while(ch != 0xc0);


	printf("%s L_%d\n", __FUNCTION__, __LINE__);
	i = 0;
	do
	{
		read(connfd, &ch, 1);
		if (ch != 0xc0)
		{
			resp[i++] = ch;
		}
		
	}while (ch != 0xc0);	

	
	printf("%s L_%d\n", __FUNCTION__, __LINE__);
	
	cmd_ls_resp(resp, i);

	free(resp);
	
}

void get_file(int sock, char *filename, int filesize)
{
	int fd = open(filename, O_WRONLY | O_TRUNC | O_CREAT, 0660);
	if (fd == -1)
	{}

	printf("%s size : %d\n", filename, filesize);

	int total_recv = 0;
	int r;
	
	while (total_recv < filesize)
	{
		char buf[1024];
		r = read(sock, buf,  (filesize - total_recv) > 1024 ?  1024 :  (filesize - total_recv));
		if (r > 0)
		{
			write_check(fd, buf, r);
			total_recv += r;
		}
		else if (r <= 0)
		{
			break;
		}
	}
	close(fd);
	
	
}

void cmd_get(int sock, unsigned char *cmd)
{
	//cmd: "get     	XXXX.TXT"
	//unsigned char  send_cmd[512];
	unsigned char filename[256];
	unsigned char buf[256];
	int i = 0;

	sscanf(cmd, "%s%s",buf, filename);

	printf("filename: %s\n", filename);


	//4(pkg_Len) + 4(cmd_no) +  [4(arg_1_,len) + arg_1_len(filename) ]

	int cmd_no = FTP_CMD_GET;
	int arg_1_len = strlen(filename) + 1; // + '\0'
	int pkg_len = 4 + 4 + 4 + arg_1_len;
	unsigned char *send_cmd = malloc(pkg_len);


	printf("%s L_%d\n", __FUNCTION__, __LINE__);

	send_cmd[i++] = 0xc0; //��ͷ

		//�����ĸ��ֽ�Ϊpkg_len, ΪС��ģʽ
	send_cmd[i++] = pkg_len & 0xff;
	send_cmd[i++] = (pkg_len >> 8) & 0xff;
	send_cmd[i++] = (pkg_len >> 16) & 0xff;
	send_cmd[i++] = (pkg_len >> 24) & 0xff;


		//�����ĸ��ֽ�Ϊ����ţ�ΪС��ģʽ
	send_cmd[i++] = cmd_no & 0xff;
	send_cmd[i++] = (cmd_no >> 8) & 0xff;
	send_cmd[i++] = (cmd_no >> 16) & 0xff;
	send_cmd[i++] = (cmd_no >> 24) & 0xff;


		//����Ϊ����1(��������(4) + ��������)
	send_cmd[i++] = arg_1_len & 0xff;
	send_cmd[i++] = (arg_1_len >> 8) & 0xff;
	send_cmd[i++] = (arg_1_len >> 16) & 0xff;
	send_cmd[i++] = (arg_1_len >> 24) & 0xff;

	int j;
	for (j = 0; send_cmd[i] = filename[j];i++, j++)
	{	
		
	}
	i++;

	send_cmd[i++] = 0xc0;


	int r = write_check(sock, send_cmd, i);
	if (r != i)
	{
		printf("%s L_%d\n", __FUNCTION__, __LINE__);
	}

	printf("%s L_%d\n", __FUNCTION__, __LINE__);



	/*���շ������Ļظ�*/

	/**/
	unsigned char *resp = malloc(8192);
	unsigned char ch;
	do 
	{
		read(sock, &ch, 1);
		
	}while(ch != 0xc0);


	printf("%s L_%d\n", __FUNCTION__, __LINE__);
	i = 0;
	do
	{
		read(sock, &ch, 1);
		if (ch != 0xc0)
		{
			resp[i++] = ch;
		}
		
	}while (ch != 0xc0);	

	int filesize = 0;
	if ( cmd_get_resp( resp , i, &filesize) == RESP_SUCCESS)
	{
		/*�����ļ�����: 4(�ļ���С) + �ļ�����*/

		get_file(sock, filename, filesize);
	}

	return;

}


int main(int argc, char *argv[])
{

	/*socket -> connect*/

	int sock;

	/*
	step 1:����һ���׽���(SOCK_STREAM)
	*/
	sock = socket(AF_INET, SOCK_STREAM, 0);
	if (sock == -1)
	{
		perror("socket error:");
		return -1;
	}


	/*
	step 2: ��һ��"������֪"�Ķ˿�
	*/
	struct sockaddr_in sAddr;
	memset(&sAddr, 0, sizeof(sAddr));
	sAddr.sin_family = AF_INET;
			//atoi��һ�������ַ������һ������
			//atoi("1234") =>  1234
	sAddr.sin_port = htons ( atoi(argv[2]) );
	sAddr.sin_addr.s_addr = inet_addr(argv[1]); 
	//sAddr.sin_addr.s_addr = htonl(  INADDR_ANY );
	
	int r = connect(sock, (struct sockaddr*) &sAddr, sizeof(sAddr));
	if (r == -1)
	{
		perror("connect error:");
		return -1;
	}
	
	char cmd[256];


	while (!ternimate)
	{
		/*step 1 : ��������*/
		fgets(cmd, 256, stdin);


		printf("cmd: %s\n", cmd);
		/*step 2: ��������*/
		if (strncmp(cmd, "ls", 2) == 0)
		{
			cmd_ls(sock, cmd);
		} else if (strncmp(cmd, "get", 3) == 0)
		{
			cmd_get(sock, cmd);
		}
	
	}

}
